import Api from "@/services/Api";
import { errorAlert } from "@/utils/alerts";

const api = new Api();

export const asyncGetNews = async () => {
  try {
    await api.get("/getNews").then(async (res: any) => {
      if (res && res?.isSuccess) {
        return res.data;
      }
    });
  } catch (e: any) {
    errorAlert(e.message);
    return null;
  }
};

export const asyncAddNews = async (payload: any) => {
  try {
    await api.post("/addNews", payload).then(async (res: any) => {
      if (res && res?.isSuccess) {
        return res.data;
      }
    });
  } catch (e: any) {
    errorAlert(e.message);
    return null;
  }
};

export const asyncSearchNews = async (payload: any) => {
  try {
    await api.get("/searchNews", payload).then(async (res: any) => {
      if (res && res?.isSuccess) {
        return res.data;
      }
    });
  } catch (e: any) {
    errorAlert(e.message);
    return null;
  }
};
