import { FC } from "react";

interface TestProps {
    
}
 
const Test: FC<TestProps> = () => {
    return (<div>TEst</div>);
}
 
export default Test;